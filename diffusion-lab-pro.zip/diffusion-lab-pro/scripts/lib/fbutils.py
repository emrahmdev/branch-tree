from pathlib import Path
from zipfile import ZipFile


class FileBrowserUtils:
    @staticmethod
    def list_files(directory: Path):
        file_list = []
        dir_list = []

        for x in directory.iterdir():
            if x.is_file():
                file_list.append(x)
            else:
                dir_list.append(x)

        def get_file_info(file: Path):
            stats = file.stat()
            return {
                'name': file.name,
                'size': FileBrowserUtils.human_size(stats.st_size),
                'time': FileBrowserUtils.pretty_date(int(stats.st_ctime)),
                'ctime': stats.st_ctime,
                'path': file
            }

        file_list = list(map(lambda f: get_file_info(f), file_list))
        dir_list = list(map(lambda f: get_file_info(f), dir_list))

        return dir_list, file_list

    @staticmethod
    def get_output_dir(img_dir):
        return Path.cwd().joinpath('outputs').joinpath(img_dir)

    @staticmethod
    def get_absolute_path(folder):
        return Path.cwd().joinpath(folder)

    @staticmethod
    def human_size(bytes, units=None):
        """ Returns a human readable string representation of bytes """
        if units is None:
            units = [' bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']
        return str(bytes) + units[0] if bytes < 1024 else FileBrowserUtils.human_size(bytes >> 10, units[1:])

    @staticmethod
    def pretty_date(time=False):
        """
        Get a datetime object or a int() Epoch timestamp and return a
        pretty string like 'an hour ago', 'Yesterday', '3 months ago',
        'just now', etc
        """
        from datetime import datetime
        now = datetime.now()
        if type(time) is int:
            diff = now - datetime.fromtimestamp(time)
        elif isinstance(time, datetime):
            diff = now - time
        elif not time:
            diff = 0
        second_diff = diff.seconds
        day_diff = diff.days

        if day_diff < 0:
            return ''

        if day_diff == 0:
            if second_diff < 10:
                return "just now"
            if second_diff < 60:
                return str(second_diff) + " seconds ago"
            if second_diff < 120:
                return "a minute ago"
            if second_diff < 3600:
                return str(second_diff // 60) + " minutes ago"
            if second_diff < 7200:
                return "an hour ago"
            if second_diff < 86400:
                return str(second_diff // 3600) + " hours ago"
        if day_diff == 1:
            return "Yesterday"
        if day_diff < 7:
            return str(day_diff) + " days ago"
        if day_diff < 31:
            return str(day_diff // 7) + " weeks ago"
        if day_diff < 365:
            return str(day_diff // 30) + " months ago"
        return str(day_diff // 365) + " years ago"

    @staticmethod
    def zip_dirs(zip_name, directories):
        zip_file = ZipFile(zip_name, mode='a')
        for directory in directories:
            for x in directory.iterdir():
                if x.is_file():
                    zip_file.write(str(x), x.name)
        zip_file.close()
