import sys

from fastapi import FastAPI, Response, Request, File, UploadFile, BackgroundTasks
from fastapi.encoders import jsonable_encoder
from fastapi.params import Query
from fastapi.responses import JSONResponse, FileResponse
import os.path
from pathlib import WindowsPath, Path
from .fbutils import FileBrowserUtils
from .file_downloader import FileDownloader
from fastapi.middleware.cors import CORSMiddleware


class ImageBrowserApi:
    root_dirs = {
        'outputs': {
            'is_dir': True,
            'real_path': 'outputs',
            'parent': False
        },
        'models': {
            'is_dir': True,
            'real_path': 'models',
            'parent': False
        },
        'embeddings': {
            'is_dir': True,
            'real_path': 'embeddings',
            'parent': False
        }
    }

    def __init__(self, file_downloader):
        self.file_downloader: FileDownloader = file_downloader

    def create_api_route(self, app: FastAPI):

        app.add_middleware(
            CORSMiddleware,
            allow_origins=[
                "http://localhost",
                "http://localhost:4200",
                "https://diffusionlabpro.com"
            ],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        @app.get("/image_browser/list")
        async def list_files(p: str = Query(None)):
            if p == 'root':
                return JSONResponse(content=jsonable_encoder(self.root_dirs))

            path_list = p.split('/', 2)

            if len(path_list) < 2 or path_list[0] != 'root' or path_list[1] not in self.root_dirs:
                return Response(status_code=404)

            real_path = FileBrowserUtils.get_absolute_path(self.root_dirs[path_list[1]]['real_path'])

            if len(path_list) > 2:
                real_path = real_path.joinpath(path_list[2])

            fd_tup = FileBrowserUtils.list_files(FileBrowserUtils.get_output_dir(real_path))

            dir_list = fd_tup[0]
            file_list = fd_tup[1]

            fd_response = {}

            for d in dir_list:
                path = d['path'].relative_to(Path.cwd())
                path = (str(path).replace('\\', '/') if type(path) is WindowsPath else str(path))
                fd_response[d['name']] = {
                    'is_dir': True,
                    'parent': True,
                    'real_path': path,
                    'size': d['size'],
                    'time': d['time'],
                    'ctime': d['ctime']
                }

            for f in file_list:
                fd_response[f['name']] = {
                    'is_dir': False,
                    'parent': True,
                    'real_path': str(f['path']),
                    'size': f['size'],
                    'time': f['time'],
                    'ctime': f['ctime']
                }

            return JSONResponse(content=jsonable_encoder(fd_response))

        @app.get("/image_browser/tozip")
        async def to_zip(p: str = Query(None)):
            folder = Path.cwd().joinpath(p)
            zip_name = p.split('/')[-1] + '.zip'

            if os.path.exists(zip_name):
                os.unlink(zip_name)

            FileBrowserUtils.zip_dirs(zip_name, [folder])

            return FileResponse(path=zip_name, filename=zip_name)

        @app.post("/image_browser/upload")
        def upload(file: UploadFile = File(...), p: str = Query(None)):
            file_path = Path.cwd().joinpath(p.split('/', 1)[-1]).joinpath(file.filename)

            try:
                with open(file_path, 'wb') as f:
                    while contents := file.file.read(1024 * 1024):
                        f.write(contents)
            except Exception:
                return Response(status_code=500)
            finally:
                file.file.close()

            return Response(status_code=200)

        @app.get("/image_browser/restart")
        def restart():
            self.file_downloader.stop()
            os.execl(sys.executable, '"{}"'.format(sys.executable), *sys.argv)
            return Response(status_code=200)

        @app.post("/image_browser/download")
        async def downloadFile(request: Request):
            data = await request.json()
            self.file_downloader.file_state[data['uid']] = 0.00001
            self.file_downloader.queue.append(data)
            return Response(status_code=200)

        @app.get("/image_browser/check_download")
        async def check_download():
            return JSONResponse(content=jsonable_encoder(self.file_downloader.file_state))
