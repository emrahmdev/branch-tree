from time import sleep

from pathlib import Path
from threading import Thread
import requests


class FileDownloader:

    def __init__(self):
        self.queue = []
        self._thread = None
        self._state = True
        self.file_state = {}
        self.number_of_threads = 4
        self.download_threads = []

    def _main_loop(self):
        while self._state:
            if len(self.queue) == 0:
                sleep(5)
                continue

            self.download_threads[:] = [x for x in self.download_threads if x.is_alive()]

            if len(self.download_threads) == self.number_of_threads:
                sleep(5)
                continue

            file = self.queue.pop()
            thread = self.start_download_thread(file)
            self.download_threads.append(thread)
            thread.start()
            sleep(1)

    def start_download_thread(self, file):
        _thread = Thread(target=self._downloadFile, args=[file])
        _thread.daemon = True
        return _thread

    def _downloadFile(self, file):
        path = Path.cwd().joinpath(file['path']).joinpath(file['name'])
        dsize = 0
        try:
            with requests.get(file['download_link'], stream=True) as r:
                r.raise_for_status()
                with open(path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
                        dsize += 8192
                        self.file_state[file['uid']] = float(float(dsize / file['size']))
                        f.flush()

            self.file_state[file['uid']] = 2
        except Exception as e:
            print(e)
            self.file_state[file['uid']] = 3

    def start(self):
        self._thread = Thread(target=self._main_loop, name='FileDownloader')
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._state = False
        self._thread.join()
        del self._thread
