from typing import Any
from modules import script_callbacks
from fastapi import FastAPI
from scripts.lib.api import ImageBrowserApi
from scripts.lib.file_downloader import FileDownloader


def init_app(_: Any, app: FastAPI, **kwargs):
    file_downloader = FileDownloader()
    api = ImageBrowserApi(file_downloader)
    api.create_api_route(app)
    file_downloader.start()


script_callbacks.on_app_started(init_app)
